@echo off
setlocal
title PS4 Music Notify - Desinstalador
echo Cerrando PS4 Music Notify si esta abierto...
powershell -NoProfile -Command "Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -like '*ps4_music_notify*' -and $_.ProcessId -ne $PID } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }"
timeout /t 1 /nobreak >nul

echo Borrando archivos y accesos directos...
rd /s /q "%APPDATA%\PS4MusicNotify" 2>nul
del /q "%APPDATA%\Microsoft\Windows\Start Menu\Programs\PS4 Music Notify.lnk" 2>nul
del /q "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\PS4 Music Notify.lnk" 2>nul

echo.
echo PS4 Music Notify fue desinstalado.
echo (Los componentes de Python winsdk y pillow se quedan; no molestan.)
echo.
pause
