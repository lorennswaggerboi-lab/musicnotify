@echo off
setlocal
title PS4 Music Notify - Instalador
cd /d "%~dp0"

echo ================================================
echo   PS4 Music Notify - Instalador para Windows
echo ================================================
echo.

if not exist "ps4_music_notify.py" goto :sin_script

set "PY="
call :buscar
if defined PY goto :tengo_python

echo No encontre una version compatible de Python 3.9 a 3.12.
where winget >nul 2>nul
if errorlevel 1 goto :sin_winget
echo Instalando Python 3.12 con winget. Puede tardar unos minutos y
echo Windows puede pedirte permiso. Aceptalo para continuar...
echo.
winget install -e --id Python.Python.3.12 --accept-package-agreements --accept-source-agreements
call :buscar
if defined PY goto :tengo_python
echo.
echo Python se instalo, pero Windows necesita refrescar su configuracion.
echo Cierra esta ventana y vuelve a hacer doble clic en este instalador.
pause
exit /b 1

:tengo_python
echo Usando Python: %PY%
echo.
echo [1/2] Instalando componentes necesarios...
%PY% -m pip install --user --disable-pip-version-check winsdk pillow
if errorlevel 1 goto :fallo
echo.
echo [2/2] Instalando PS4 Music Notify...
%PY% "%~dp0ps4_music_notify.py" --install
if errorlevel 1 goto :fallo
echo.
echo ================================================
echo   Listo! PS4 Music Notify ya esta funcionando.
echo ================================================
echo - Aparece en el menu Inicio como PS4 Music Notify.
echo - Se abre solo cada vez que inicias Windows.
echo - Pone musica en Spotify o YouTube y cambia de cancion para probarlo.
echo.
pause
exit /b 0

:fallo
echo.
echo Algo fallo durante la instalacion. Revisa el mensaje de arriba.
pause
exit /b 1

:sin_script
echo No encuentro ps4_music_notify.py junto a este instalador.
echo Extrae TODO el contenido del .zip en una carpeta y vuelve a intentar.
pause
exit /b 1

:sin_winget
echo No puedo instalar Python automaticamente en este equipo.
echo Instala Python 3.12 desde https://www.python.org/downloads/
echo (marca la casilla "Add python.exe to PATH") y despues vuelve a
echo hacer doble clic en este instalador.
start https://www.python.org/downloads/
pause
exit /b 1

:buscar
for %%V in (3.12 3.11 3.10 3.9) do if not defined PY py -%%V -c "import tkinter" >nul 2>nul && set "PY=py -%%V"
if not defined PY for %%P in ("%LOCALAPPDATA%\Programs\Python\Python312\python.exe" "%ProgramFiles%\Python312\python.exe") do if not defined PY if exist %%P set PY=%%P
exit /b 0
