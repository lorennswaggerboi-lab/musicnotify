#!/usr/bin/env python3
"""
PS4 Music Notify (sin sonido)
=============================
Muestra una notificación arriba a la izquierda (estilo PS4) con la carátula,
el título y el artista cada vez que empieza una canción nueva.
Funciona en Windows y Linux.

INSTALAR (lo más fácil: doble clic)
  Ubuntu/Debian/Mint : doble clic al archivo .deb  ->  "Instalar".
  Windows            : doble clic al .exe  ->  "Sí" cuando pregunta.
  Se agrega al menú de aplicaciones y arranca solo al iniciar sesión.

INSTALAR DESDE EL .PY (otras distros o si ya tenés Python)
  Linux   : python3 ps4_music_notify.py --install
  Windows : python ps4_music_notify.py --install
  Para desinstalar:  python3 ps4_music_notify.py --uninstall

OTROS COMANDOS
  --run    abre la app sin preguntar nada
  --test   muestra una notificación de prueba
"""
import io
import math
import os
import queue
import shutil
import subprocess
import sys
import threading
import time
try:
    import tkinter as tk
    import tkinter.font as tkfont
except ImportError:          # el instalador tiene que poder correr igual
    tk = tkfont = None
import urllib.parse
import urllib.request

IS_WIN = sys.platform.startswith("win")

# ---------------------------------------------------------------- Ajustes --
TOAST_W, TOAST_H = 440, 108
COVER = 80                            # tamaño de la carátula
PAD = 14
RADIUS = 24                           # esquinas redondeadas de la tarjeta
ROUNDED_LINUX = True                  # esquinas redondeadas también en Linux (X11/XWayland)
MARGIN_X = 24
MARGIN_Y = 24 if IS_WIN else 56       # en Linux dejamos lugar para la barra superior
IN_MS = 480                           # entrada
SHOW_MS = 5200                        # tiempo visible
OUT_MS = 400                          # salida
SHINE_MS = 700                        # barrido de brillo
SHINE_W = 150
ALPHA = 0.97

CARD_BG = "#0a0c12"
KEY = "#010203"                       # color "transparente" en Windows
TEXT = "#ffffff"
TEXT_DIM = "#c3c9d6"
DEFAULT_ACCENT = (0, 112, 209)        # azul PS4 cuando no hay carátula
# ---------------------------------------------------------------------------


# ----------------------------------------------------------- Detección ------
def fetch_art(url):
    """Descarga/lee la carátula (file:// o http(s)://). Devuelve bytes o None."""
    try:
        if url.startswith("file://"):
            with open(urllib.parse.unquote(urllib.parse.urlparse(url).path), "rb") as f:
                return f.read()
        if url.startswith(("http://", "https://")):
            req = urllib.request.Request(url, headers={"User-Agent": "ps4-music-notify"})
            with urllib.request.urlopen(req, timeout=4) as r:
                return r.read(5_000_000)
    except Exception as e:
        print("No se pudo obtener la carátula:", e, file=sys.stderr)
    return None


def watch_linux(q):
    """Escucha cambios de reproducción vía MPRIS usando playerctl."""
    if not shutil.which("playerctl"):
        q.put(("error", "Falta playerctl", "Instalalo: sudo apt install playerctl"))
        return
    fmt = "{{status}}\t{{artist}}\t{{title}}\t{{mpris:artUrl}}"
    last = None
    while True:
        try:
            p = subprocess.Popen(
                ["playerctl", "--follow", "metadata", "--format", fmt],
                stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True)
            for line in p.stdout:
                parts = line.rstrip("\n").split("\t")
                if len(parts) < 4:
                    continue
                status, artist, title, art_url = parts[:4]
                if status != "Playing" or not title or (artist, title) == last:
                    continue
                last = (artist, title)
                if not art_url:   # algunos reproductores mandan la carátula después
                    time.sleep(0.6)
                    art_url = subprocess.run(
                        ["playerctl", "metadata", "mpris:artUrl"],
                        capture_output=True, text=True).stdout.strip()
                q.put(("track", artist, title, fetch_art(art_url) if art_url else None))
            p.wait()
        except Exception as e:
            print("playerctl:", e, file=sys.stderr)
        time.sleep(2)


def watch_windows(q):
    """Escucha el reproductor de medios del sistema (el del control de volumen)."""
    try:
        import asyncio
        from winsdk.windows.media.control import (
            GlobalSystemMediaTransportControlsSessionManager as Manager,
            GlobalSystemMediaTransportControlsSessionPlaybackStatus as Status,
        )
        from winsdk.windows.storage.streams import DataReader
    except ImportError:
        q.put(("error", "Falta winsdk", "Ejecutá: pip install winsdk"))
        return

    async def read_thumb(info):
        try:
            ref = info.thumbnail
            if not ref:
                return None
            stream = await ref.open_read_async()
            size = stream.size
            if not size:
                return None
            reader = DataReader(stream)
            await reader.load_async(size)
            data = bytearray(size)
            reader.read_bytes(data)
            return bytes(data)
        except Exception as e:
            print("thumbnail:", e, file=sys.stderr)
            return None

    async def poll():
        mgr = await Manager.request_async()
        last = None
        while True:
            try:
                session = mgr.get_current_session()
                if session and session.get_playback_info().playback_status == Status.PLAYING:
                    info = await session.try_get_media_properties_async()
                    if info and info.title:
                        key = (info.artist, info.title)
                        if key != last:
                            last = key
                            await asyncio.sleep(0.5)   # dejar que cargue la carátula
                            info = await session.try_get_media_properties_async() or info
                            q.put(("track", info.artist or "", info.title,
                                   await read_thumb(info)))
            except Exception as e:
                print("media poll:", e, file=sys.stderr)
            await asyncio.sleep(1)

    asyncio.run(poll())


# ------------------------------------------------------------------- UI -----
def _res(name):                      # compatibilidad entre versiones de Pillow
    from PIL import Image
    return getattr(getattr(Image, "Resampling", Image), name)


def _trf(name):
    from PIL import Image
    return getattr(getattr(Image, "Transform", Image), name)


def _square(im):
    s = min(im.size)
    left, top = (im.width - s) // 2, (im.height - s) // 2
    return im.crop((left, top, left + s, top + s))


def _rounded_mask(w, h, r, ss=4):
    """Máscara con esquinas redondeadas y bordes suaves (supermuestreo)."""
    from PIL import Image, ImageDraw
    m = Image.new("L", (w * ss, h * ss), 0)
    ImageDraw.Draw(m).rounded_rectangle([0, 0, w * ss - 1, h * ss - 1], radius=r * ss, fill=255)
    return m.resize((w, h), _res("LANCZOS"))


def _accent_from(im):
    """Color vistoso dominante de la carátula."""
    import colorsys
    q = im.resize((48, 48)).quantize(colors=8)
    pal = q.getpalette()
    best, best_score = None, -1.0
    for count, idx in q.getcolors(maxcolors=256):
        r, g, b = pal[idx * 3: idx * 3 + 3]
        hh, ss, vv = colorsys.rgb_to_hsv(r / 255, g / 255, b / 255)
        score = count * (0.25 + ss) * (0.2 + vv)
        if vv > 0.25 and ss > 0.15 and score > best_score:
            best, best_score = (hh, ss, vv), score
    if best is None:
        return DEFAULT_ACCENT
    hh, ss, vv = best
    r, g, b = colorsys.hsv_to_rgb(hh, max(ss, 0.55), max(vv, 0.88))
    return int(r * 255), int(g * 255), int(b * 255)


def _fallback_cover(size=256, note=True):
    """Carátula por defecto: degradé azul con notita musical."""
    from PIL import Image, ImageDraw, ImageOps
    g = Image.linear_gradient("L").resize((size, size))
    im = ImageOps.colorize(g, "#06285a", "#2d8cff").convert("RGB")
    if not note:
        return im
    d = ImageDraw.Draw(im)
    k = size / 100.0
    d.ellipse([26 * k, 58 * k, 50 * k, 76 * k], fill="white")
    d.rectangle([45 * k, 24 * k, 51 * k, 68 * k], fill="white")
    d.polygon([(51 * k, 24 * k), (74 * k, 33 * k), (74 * k, 45 * k), (51 * k, 36 * k)], fill="white")
    return im


def render_card_images(art_bytes, w, h, radius, cover_px):
    """Dibuja el fondo de la tarjeta, la carátula redondeada y el brillo (Pillow)."""
    from PIL import Image, ImageChops, ImageDraw, ImageFilter, ImageOps
    lanczos = _res("LANCZOS")

    art = None
    if art_bytes:
        try:
            art = _square(Image.open(io.BytesIO(art_bytes)).convert("RGB"))
        except Exception:
            art = None
    accent = _accent_from(art) if art is not None else DEFAULT_ACCENT
    if art is None:
        art = _fallback_cover()
        bg_src = _fallback_cover(note=False)      # el fondo no necesita la notita
    else:
        bg_src = art

    # Fondo: carátula desenfocada y oscurecida, con tinte del color de acento a la derecha
    base = bg_src.resize((w, w), lanczos)
    top = (w - h) // 2
    base = base.crop((0, top, w, top + h)).filter(ImageFilter.GaussianBlur(18))
    base = Image.blend(base, Image.new("RGB", (w, h), (8, 10, 16)), 0.62)
    ramp = Image.linear_gradient("L").rotate(90, expand=True).resize((w, h))
    base = Image.composite(Image.new("RGB", (w, h), accent), base, ramp.point(lambda v: int(v * 0.30)))
    gloss = ImageOps.flip(Image.linear_gradient("L").resize((w, h)))
    base = Image.composite(Image.new("RGB", (w, h), (255, 255, 255)), base,
                           gloss.point(lambda v: int(v * 0.09)))

    # Borde luminoso del color de acento
    ss = 4
    border = Image.new("RGBA", (w * ss, h * ss), (0, 0, 0, 0))
    ImageDraw.Draw(border).rounded_rectangle(
        [1, 1, w * ss - 2, h * ss - 2], radius=radius * ss,
        outline=accent + (190,), width=2 * ss)
    bg = Image.alpha_composite(base.convert("RGBA"), border.resize((w, h), lanczos))
    mask = _rounded_mask(w, h, radius)
    bg.putalpha(mask)

    # Carátula con esquinas redondeadas y filo sutil
    cov = art.resize((cover_px, cover_px), lanczos).convert("RGBA")
    edge = Image.new("RGBA", (cover_px * ss, cover_px * ss), (0, 0, 0, 0))
    ImageDraw.Draw(edge).rounded_rectangle(
        [1, 1, cover_px * ss - 2, cover_px * ss - 2], radius=16 * ss,
        outline=(255, 255, 255, 70), width=ss)
    cov = Image.alpha_composite(cov, edge.resize((cover_px, cover_px), lanczos))
    cov.putalpha(_rounded_mask(cover_px, cover_px, 16))

    # Brillo diagonal que cruza la tarjeta al aparecer
    band = Image.new("L", (SHINE_W, h), 0)
    px = band.load()
    for x in range(SHINE_W):
        v = int(70 * max(0.0, 1 - abs(x - SHINE_W / 2) / 32))
        for y in range(h):
            px[x, y] = v
    band = band.transform((SHINE_W, h), _trf("AFFINE"), (1, 0.55, -0.55 * h / 2, 0, 1, 0),
                          _res("BILINEAR"))
    shine = Image.new("RGBA", (SHINE_W, h), (255, 255, 255, 0))
    shine.putalpha(band)

    return {"bg": bg, "cover": cov, "shine": shine, "mask": mask, "accent": accent}


def _shine_frame(imgs, x):
    from PIL import Image, ImageChops
    layer = Image.new("RGBA", imgs["bg"].size, (0, 0, 0, 0))
    layer.paste(imgs["shine"], (x, 0))
    layer.putalpha(ImageChops.multiply(layer.getchannel("A"), imgs["mask"]))
    return Image.alpha_composite(imgs["bg"], layer)


_BITREV = bytes(int(f"{i:08b}"[::-1], 2) for i in range(256))


def _x11_round(win, mask):
    """Recorta la ventana con la forma de la tarjeta (extensión Shape de X11)."""
    import ctypes
    import ctypes.util
    x11 = ctypes.CDLL(ctypes.util.find_library("X11") or "libX11.so.6")
    xext = ctypes.CDLL(ctypes.util.find_library("Xext") or "libXext.so.6")
    VP, UL, CI = ctypes.c_void_p, ctypes.c_ulong, ctypes.c_int
    x11.XOpenDisplay.restype, x11.XOpenDisplay.argtypes = VP, [ctypes.c_char_p]
    x11.XDefaultRootWindow.restype, x11.XDefaultRootWindow.argtypes = UL, [VP]
    x11.XCreateBitmapFromData.restype = UL
    x11.XCreateBitmapFromData.argtypes = [VP, UL, ctypes.c_char_p, ctypes.c_uint, ctypes.c_uint]
    x11.XQueryTree.argtypes = [VP, UL, ctypes.POINTER(UL), ctypes.POINTER(UL),
                               ctypes.POINTER(ctypes.POINTER(UL)), ctypes.POINTER(ctypes.c_uint)]
    x11.XFree.argtypes = [VP]
    x11.XFreePixmap.argtypes = [VP, UL]
    x11.XSync.argtypes = [VP, CI]
    x11.XCloseDisplay.argtypes = [VP]
    xext.XShapeCombineMask.argtypes = [VP, UL, CI, CI, CI, UL, CI]

    w, h = mask.size
    data = mask.point(lambda v: 255 if v > 127 else 0).convert("1").tobytes().translate(_BITREV)
    dpy = x11.XOpenDisplay(None)
    if not dpy:
        raise RuntimeError("sin conexión a X11")
    try:
        pix = x11.XCreateBitmapFromData(dpy, x11.XDefaultRootWindow(dpy), data, w, h)
        targets = [win.winfo_id()]
        root_r, parent, kids, n = UL(), UL(), ctypes.POINTER(UL)(), ctypes.c_uint()
        if x11.XQueryTree(dpy, targets[0], ctypes.byref(root_r), ctypes.byref(parent),
                          ctypes.byref(kids), ctypes.byref(n)):
            if kids:
                x11.XFree(ctypes.cast(kids, VP))
            if parent.value and parent.value != root_r.value:
                targets.append(parent.value)      # ventana "envoltorio" de Tk, si existe
        for t in targets:
            xext.XShapeCombineMask(dpy, t, 0, 0, 0, pix, 0)   # ShapeBounding, ShapeSet
        x11.XFreePixmap(dpy, pix)
        x11.XSync(dpy, 0)
    finally:
        x11.XCloseDisplay(dpy)


def _ease_out_back(t):
    c1 = 1.0
    c3 = c1 + 1
    return 1 + c3 * (t - 1) ** 3 + c1 * (t - 1) ** 2


def _ease_in_back(t):
    c1 = 1.0
    c3 = c1 + 1
    return c3 * t ** 3 - c1 * t ** 2


class Toast:
    def __init__(self, root):
        self.root = root
        self.win = None
        self.job = None
        self.keep = []               # referencias para que Tk no libere las imágenes
        self._fam = None

    def close(self):
        if self.job:
            try:
                self.root.after_cancel(self.job)
            except Exception:
                pass
            self.job = None
        if self.win:
            try:
                self.win.destroy()
            except Exception:
                pass
            self.win = None
        self.keep = []

    def _family(self):
        if self._fam is None:
            try:
                fams = set(tkfont.families(self.root))
            except Exception:
                fams = set()
            for f in ("Segoe UI", "Inter", "Noto Sans", "Ubuntu", "Cantarell", "DejaVu Sans"):
                if f in fams:
                    self._fam = f
                    break
            else:
                self._fam = tkfont.nametofont("TkDefaultFont").actual("family")
        return self._fam

    @staticmethod
    def _fit(text, font, max_w):
        if font.measure(text) <= max_w:
            return text
        while text and font.measure(text + "…") > max_w:
            text = text[:-1]
        return text.rstrip() + "…"

    def _render(self, art):
        try:
            from PIL import ImageTk
            d = render_card_images(art, TOAST_W, TOAST_H, RADIUS, COVER)
            d["bg_photo"] = ImageTk.PhotoImage(d["bg"])
            d["cover_photo"] = ImageTk.PhotoImage(d["cover"])
            return d
        except Exception as e:
            print("Sin Pillow/ImageTk, uso el diseño simple:", e, file=sys.stderr)
            return None

    def show(self, title, artist, art=None):
        self.close()
        W, H = TOAST_W, TOAST_H
        w = tk.Toplevel(self.root)
        self.win = w
        w.overrideredirect(True)
        w.attributes("-topmost", True)
        if IS_WIN:
            try:
                w.attributes("-transparentcolor", KEY)
            except tk.TclError:
                pass
        try:
            w.attributes("-alpha", 0.0)
        except tk.TclError:
            pass
        w.geometry(f"{W}x{H}+{-W}+{MARGIN_Y}")

        imgs = self._render(art)
        rgb = imgs["accent"] if imgs else DEFAULT_ACCENT
        accent = "#%02x%02x%02x" % tuple(int(v + (255 - v) * 0.38) for v in rgb)   # más claro: se lee mejor
        c = tk.Canvas(w, width=W, height=H, bd=0, highlightthickness=0,
                      bg=KEY if IS_WIN else CARD_BG)
        c.pack()
        cy = H // 2

        if imgs:
            self.keep += [imgs["bg_photo"], imgs["cover_photo"]]
            c.create_image(0, 0, image=imgs["bg_photo"], anchor="nw")
            c.create_image(PAD, (H - COVER) // 2, image=imgs["cover_photo"], anchor="nw")
        else:                                   # diseño simple si no hay Pillow
            c.create_rectangle(1, 1, W - 2, H - 2, fill=CARD_BG, outline=accent, width=2)
            cx = PAD + COVER // 2
            c.create_oval(PAD, (H - COVER) // 2, PAD + COVER, (H + COVER) // 2,
                          fill=accent, outline="")
            c.create_oval(cx - 16, cy + 6, cx - 2, cy + 16, fill="white", outline="")
            c.create_line(cx - 3, cy + 11, cx - 3, cy - 16, fill="white", width=4)
            c.create_line(cx - 3, cy - 16, cx + 11, cy - 9, fill="white", width=4)

        fam = self._family()
        f_lab = tkfont.Font(family=fam, size=8, weight="bold")
        f_title = tkfont.Font(family=fam, size=15, weight="bold")
        f_art = tkfont.Font(family=fam, size=11)
        tx = PAD + COVER + 16
        max_w = W - tx - 62
        t = self._fit(title, f_title, max_w)
        c.create_text(tx, cy - 30, anchor="w", text="REPRODUCIENDO AHORA", fill=accent, font=f_lab)
        c.create_text(tx + 1, cy - 3, anchor="w", text=t, fill="#000000", font=f_title)   # sombra
        c.create_text(tx, cy - 4, anchor="w", text=t, fill=TEXT, font=f_title)
        if artist:
            c.create_text(tx, cy + 24, anchor="w", text=self._fit(artist, f_art, max_w),
                          fill=TEXT_DIM, font=f_art)

        # Ecualizador animado
        n, bw, gap = 4, 5, 4
        ex = W - 26 - (n * bw + (n - 1) * gap)
        base = cy + 16
        bars = [c.create_rectangle(ex + i * (bw + gap), base - 6, ex + i * (bw + gap) + bw, base,
                                   fill=accent, outline="") for i in range(n)]
        # Barra de tiempo restante
        px0, px1, py = 28, W - 28, H - 8
        prog = c.create_rectangle(px0, py, px1, py + 2, fill=accent, outline="")

        if imgs and not IS_WIN and ROUNDED_LINUX and os.environ.get("DISPLAY"):
            try:
                w.update_idletasks()
                _x11_round(w, imgs["mask"])
            except Exception as e:
                print("Esquinas redondeadas no disponibles:", e, file=sys.stderr)

        t0 = time.monotonic()
        state = {"shine": -1}
        out_at = IN_MS + SHOW_MS

        def tick():
            if self.win is not w:
                return
            t = (time.monotonic() - t0) * 1000.0
            if t < IN_MS:                                   # entra con rebote y fade-in
                p = t / IN_MS
                x = -W + (MARGIN_X + W) * _ease_out_back(p)
                a = min(1.0, p * 1.8)
            elif t < out_at:
                x, a = MARGIN_X, 1.0
            elif t < out_at + OUT_MS:                       # sale con tirón y fade-out
                p = (t - out_at) / OUT_MS
                x = MARGIN_X + (-W - MARGIN_X) * _ease_in_back(p)
                a = 1.0 - max(0.0, (p - 0.4) / 0.6)
            else:
                self.close()
                return
            w.geometry(f"+{int(x)}+{MARGIN_Y}")
            try:
                w.attributes("-alpha", ALPHA * a)
            except tk.TclError:
                pass

            s = t / 1000.0                                  # ecualizador
            for i, b in enumerate(bars):
                v = 0.5 + 0.5 * math.sin(s * (5.5 + i * 1.9) + i * 2.1) * (0.6 + 0.4 * math.sin(s * 2.3 + i))
                bx = ex + i * (bw + gap)
                c.coords(b, bx, base - (5 + 22 * v), bx + bw, base)

            if t < IN_MS:                                   # barra de tiempo
                frac = 1.0
            elif t < out_at:
                frac = 1.0 - (t - IN_MS) / SHOW_MS
            else:
                frac = 0.0
            c.coords(prog, px0, py, px0 + (px1 - px0) * frac, py + 2)

            if imgs:                                        # barrido de brillo
                sp = (t - (IN_MS - 100)) / SHINE_MS
                if 0 <= sp <= 1:
                    idx = int(sp * 24)
                    if idx != state["shine"]:
                        state["shine"] = idx
                        imgs["bg_photo"].paste(_shine_frame(imgs, int(-SHINE_W + (W + SHINE_W) * sp)))
                elif sp > 1 and state["shine"] != -2:
                    state["shine"] = -2
                    imgs["bg_photo"].paste(imgs["bg"])

            self.job = self.root.after(16, tick)

        tick()


def _demo_cover():
    """Carátula de prueba para --test (solo si hay Pillow)."""
    try:
        from PIL import Image
        im = Image.new("RGB", (200, 200))
        px = im.load()
        for y in range(200):
            for x in range(200):
                px[x, y] = (40 + x // 2, 60 + y // 3, 200 - x // 2)
        buf = io.BytesIO()
        im.save(buf, "PNG")
        return buf.getvalue()
    except Exception:
        return None


# ------------------------------------------------------------ Instalador ----
APP_NAME = "PS4 Music Notify"
APP_ID = "ps4-music-notify"


def install_dir():
    if IS_WIN:
        return os.path.join(os.environ.get("APPDATA", os.path.expanduser("~")), "PS4MusicNotify")
    return os.path.join(os.path.expanduser("~/.local/share"), APP_ID)


def _frozen():
    return getattr(sys, "frozen", False)      # True dentro del .exe de PyInstaller


def _self_path():
    return os.path.abspath(sys.executable if _frozen() else __file__)


def installed_script():
    if _frozen():
        name = "ps4-music-notify.exe" if IS_WIN else "ps4-music-notify"
    else:
        name = "ps4_music_notify.py"
    return os.path.join(install_dir(), name)


def is_installed():
    return _self_path() == installed_script()


def single_instance():
    """Evita que corran dos copias a la vez. Devuelve el socket o None si ya hay una."""
    import socket
    s = socket.socket()
    try:
        s.bind(("127.0.0.1", 47653))
    except OSError:
        return None
    return s


# Paquetes por gestor de paquetes: (comando, {dependencia: [paquetes]})
_MANAGERS = {
    "apt-get": (["apt-get", "install", "-y"],
                {"tk": ["python3-tk"], "pil": ["python3-pil", "python3-pil.imagetk"],
                 "playerctl": ["playerctl"]}),
    "dnf": (["dnf", "install", "-y"],
            {"tk": ["python3-tkinter"], "pil": ["python3-pillow", "python3-pillow-tk"],
             "playerctl": ["playerctl"]}),
    "pacman": (["pacman", "-S", "--needed", "--noconfirm"],
               {"tk": ["tk"], "pil": ["python-pillow"], "playerctl": ["playerctl"]}),
    "zypper": (["zypper", "install", "-y"],
               {"tk": ["python3-tk"], "pil": ["python3-Pillow", "python3-Pillow-tk"],
                "playerctl": ["playerctl"]}),
}


def _linux_missing():
    missing = []
    if tk is None:
        missing.append("tk")
    try:
        from PIL import ImageTk  # noqa: F401
    except Exception:
        missing.append("pil")
    if not shutil.which("playerctl"):
        missing.append("playerctl")
    return missing


def _ensure_linux_deps():
    missing = _linux_missing()
    if not missing:
        return
    for mgr, (prefix, pk) in _MANAGERS.items():
        if shutil.which(mgr):
            break
    else:
        print("Faltan dependencias (" + ", ".join(missing) + ") y no reconozco tu gestor de paquetes.")
        print("Instalá: tkinter, Pillow con ImageTk y playerctl.")
        return
    cmd = ["sudo"] + prefix + [p for m in missing for p in pk[m]]
    print("Faltan dependencias:", ", ".join(missing))
    print("  " + " ".join(cmd))
    if sys.stdin.isatty():
        if input("¿Instalarlas ahora? [S/n] ").strip().lower() in ("", "s", "si", "sí", "y", "yes"):
            subprocess.call(cmd)


def _install_linux(dst):
    _ensure_linux_deps()
    entry = ("[Desktop Entry]\nType=Application\nName=" + APP_NAME + "\n"
             "Comment=Notificación estilo PS4 cuando empieza una canción\n"
             f'Exec={sys.executable} "{dst}" --run\n'
             "Icon=multimedia-audio-player\nTerminal=false\nCategories=AudioVideo;Audio;\n")
    for d in (os.path.expanduser("~/.local/share/applications"),
              os.path.expanduser("~/.config/autostart")):
        os.makedirs(d, exist_ok=True)
        with open(os.path.join(d, APP_ID + ".desktop"), "w", encoding="utf-8") as f:
            f.write(entry)
    if _linux_missing():
        print("Instalá las dependencias de arriba y después abrí «" + APP_NAME + "» desde el menú.")
        return
    subprocess.Popen([sys.executable, dst, "--run"], start_new_session=True,
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def _windows_paths():
    programs = os.path.join(os.environ["APPDATA"], "Microsoft", "Windows", "Start Menu", "Programs")
    return [os.path.join(programs, APP_NAME + ".lnk"),
            os.path.join(programs, "Startup", APP_NAME + ".lnk")]


def _install_windows(dst, base):
    if _frozen():                               # .exe: ya trae todo adentro
        target, args = dst, "--run"
    else:
        subprocess.call([sys.executable, "-m", "pip", "install", "--user", "--quiet",
                         "winsdk", "pillow"])
        target = sys.executable
        if target.lower().endswith("python.exe"):
            target = target[:-10] + "pythonw.exe"   # sin ventana de consola
        if not os.path.isfile(target):
            target = sys.executable
        args = '"%s" --run' % dst

    def q(x):
        return x.replace("'", "''")

    for lnk in _windows_paths():
        os.makedirs(os.path.dirname(lnk), exist_ok=True)
        ps = ("$s=(New-Object -ComObject WScript.Shell).CreateShortcut('%s');"
              "$s.TargetPath='%s';$s.Arguments='%s';$s.WorkingDirectory='%s';$s.Save()"
              % (q(lnk), q(target), q(args), q(base)))
        subprocess.call(["powershell", "-NoProfile", "-Command", ps])
    subprocess.Popen([target] + ([] if _frozen() else [dst]) + ["--run"])


def install():
    base = install_dir()
    os.makedirs(base, exist_ok=True)
    dst = installed_script()
    src = _self_path()
    if src != dst:
        shutil.copyfile(src, dst)
    if IS_WIN:
        _install_windows(dst, base)
    else:
        _install_linux(dst)
    print(f"Listo. {APP_NAME} quedó instalado en {base}")
    print("Aparece en el menú de aplicaciones y arranca solo al iniciar sesión.")


def uninstall():
    paths = [installed_script()]
    if IS_WIN:
        paths += _windows_paths()
    else:
        paths += [os.path.expanduser("~/.local/share/applications/" + APP_ID + ".desktop"),
                  os.path.expanduser("~/.config/autostart/" + APP_ID + ".desktop")]
    for p in paths:
        try:
            os.remove(p)
        except OSError:
            pass
    try:
        os.rmdir(install_dir())
    except OSError:
        pass
    print(f"{APP_NAME} desinstalado. Si sigue abierto, cerralo o reiniciá la sesión.")


# ----------------------------------------------------------------- Main -----
def main():
    if "--uninstall" in sys.argv:
        uninstall()
        return
    if "--install" in sys.argv:
        install()
        return
    test = "--test" in sys.argv
    if tk is None:
        print("Falta tkinter. Ejecutá:  python3 ps4_music_notify.py --install", file=sys.stderr)
        sys.exit(1)
    root = tk.Tk()
    root.withdraw()

    if not test and "--run" not in sys.argv and not is_installed():
        from tkinter import messagebox
        if messagebox.askyesno(
                APP_NAME,
                "¿Querés instalar PS4 Music Notify?\n\n"
                "Se agrega al menú de aplicaciones y arranca solo al iniciar sesión.\n\n"
                "Sí = instalar     No = abrir solo esta vez"):
            root.destroy()
            install()
            return

    lock = None
    if not test:
        lock = single_instance()
        if lock is None:
            print("Ya hay una copia corriendo.")
            root.destroy()
            return

    q = queue.Queue()
    toast = Toast(root)
    last = [None]

    if test:
        q.put(("track", "Daft Punk", "Get Lucky", _demo_cover()))
        root.after(IN_MS + SHOW_MS + OUT_MS + 1500, root.destroy)
    else:
        target = watch_windows if IS_WIN else watch_linux
        threading.Thread(target=target, args=(q,), daemon=True).start()

    def pump():
        try:
            while True:
                msg = q.get_nowait()
                if msg[0] == "track":
                    _, artist, title, art = msg
                    key = (artist, title)
                    if key != last[0]:        # solo canciones nuevas
                        last[0] = key
                        toast.show(title, artist, art)
                elif msg[0] == "error":
                    _, title, detail = msg
                    toast.show(title, detail)
        except queue.Empty:
            pass
        root.after(150, pump)

    pump()
    root.mainloop()


if __name__ == "__main__":
    main()
